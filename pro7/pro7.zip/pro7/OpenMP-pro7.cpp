#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>
#include <stdio.h>
#include <iostream>

#define NUMTRIES 20

#ifndef NUMT
#define NUMT 1
#endif

// main program:
int
main( int argc, char *argv[ ] )
{


#ifndef _OPENMP
	fprintf( stderr, "No OpenMP support!\n" );
	return 1;
#endif

    //read file
    FILE *fp = fopen( "signal.txt", "r" );
    if( fp == NULL )
    {
        fprintf( stderr, "Cannot open file 'signal.txt'\n" );
        exit( 1 );
    }
    int Size;
    fscanf( fp, "%d", &Size );
    float *A =     new float[ 2*Size ];
    float *Sums  = new float[ 1*Size ];
    for( int i = 0; i < Size; i++ )
    {
        fscanf( fp, "%f", &A[i] );
        A[i+Size] = A[i];		// duplicate the array
    }
    fclose( fp );



    omp_set_num_threads(NUMT);

    double maxPerformance = 0.;
	double avgPerformance = 0.;

	for (int t = 0; t < NUMTRIES; t++)
	{
		// start time
		double time0 = omp_get_wtime();

		#pragma omp parallel for default(none) shared(Size, A, Sums)
		for (int shift = 0; shift < Size; shift++)
		{
			float sum = 0.;
			for (int i = 0; i < Size; i++)
			{
				sum += A[i] * A[i + shift];
			}

			Sums[shift] = sum;
		}

		// end time
		double time1 = omp_get_wtime();

		double avgPerformance = (double)(Size*Size)  / (time1 - time0) / 1000000.;


		if (avgPerformance > maxPerformance)

		    maxPerformance = avgPerformance;
		
		
        //Write Data
        fp = fopen( "resultsOMP.txt", "w" );
        if( fp == NULL )
        {
            fprintf( stderr, "Cannot open file 'resultsOMP.txt' for writing\n" );
            exit( 1 );
        }
        for( int i = 0; i < 512; i++ )
        {
            fprintf( fp, "%4d\t%f\n",i, Sums[ i ] );
        }
        fclose( fp );
	}

    


    printf( "%8.2lf avgPerformance per second\n", maxPerformance );
    
    delete [ ] A;
	delete [ ] Sums;

    return 0;
    

}